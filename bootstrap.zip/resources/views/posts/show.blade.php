<x-layout>
    <x-postCard :post="$post" full={{true}}/>
</x-layout>
