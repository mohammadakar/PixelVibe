@props(['msg','bg'])


<p class="text-sm font-medium text-whitepx-3 py-3 rounded-md {{$bg}}">
    {{$msg}}
</p>
