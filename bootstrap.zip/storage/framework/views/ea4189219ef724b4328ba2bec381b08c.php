<h1>demo</h1>
<?php /**PATH C:\Users\HpPc\Desktop\laravel-11\MY_APP\resources\views/components/demo.blade.php ENDPATH**/ ?>