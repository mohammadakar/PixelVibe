<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post','full'=>false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post','full'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="card">

    <div>
        <?php if($post->image): ?>
            <img class="h-80 w-auto" src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="">
        <?php else: ?>
        <img class="h-80 w-auto" src="<?php echo e(asset('storage/posts_images/default.jpg')); ?>" alt="">
        <?php endif; ?>
    </div>

    <h2 class="font-bold text-xl m-4"><?php echo e($post->title); ?></h2>

    <div class="text-sm font-light m-4">
        <span>Posted <?php echo e($post->created_at->diffForHumans()); ?> by</span>
        <a href="<?php echo e(route('posts.user',$post->user)); ?>" class="text-blue-500 font-medium"><?php echo e($post->user->username); ?></a>
    </div>

    <?php if($full): ?>
    <div class="text-sm m-4">
        <p><?php echo e(($post->body)); ?></p>
    </div>
    <?php else: ?>
    <div class="text-sm m-4">
        <p><?php echo e(Str::words($post->body,30)); ?></p>
        <a href="<?php echo e(route('posts.show',$post)); ?>" class="text-blue-500">Read more...</a>
    </div>
    <?php endif; ?>

    <div class="flex items-center mt-6 justify-end gap-4">
        <?php echo e($slot); ?>

    </div>

</div>
<?php /**PATH C:\Users\HpPc\Desktop\laravel-11\MY_APP\resources\views/components/postCard.blade.php ENDPATH**/ ?>