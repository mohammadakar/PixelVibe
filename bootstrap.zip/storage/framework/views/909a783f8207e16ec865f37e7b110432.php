<h1>hello <?php echo e($user->username); ?></h1>

<div>
    <h2>You Created <?php echo e($post->title); ?></h2>
    <p><?php echo e($post->body); ?></p>

    <img width="300" src="<?php echo e($message->embed('storage/'. $post->image)); ?>" alt="">
</div>
<?php /**PATH C:\Users\HpPc\Desktop\laravel-11\MY_APP\resources\views/email/welcome.blade.php ENDPATH**/ ?>